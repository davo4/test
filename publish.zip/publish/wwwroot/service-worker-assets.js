﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-agkU0UJdketnBKN2v58u48GHvZwb0CFDnrsKxQByxNs=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ecvZ3YIqDfNv\/D\/erzAoX7Qm98hYP4G7dE+NBRf6u3M=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-8oJip361m8OrfLRJOuIeswWKaoxtT27\/wINCxhn+s4c=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-bN7gtVqP2mIpLB0ilKP5kcTBnBDitG1uYoLSnd\/WeBY=",
      "url": "_framework\/dotnet.5.0.17.js"
    },
    {
      "hash": "sha256-8nt7awSZZ\/ozElX3S2GNLSw89j4HBgmMmfqfIG7Gyk4=",
      "url": "BarcodeGenerator.styles.css"
    },
    {
      "hash": "sha256-diwIVjxeHOLFEgbR\/Y1KGaiVSVjdxTDsNmqbfNOidD8=",
      "url": "_framework\/Microsoft.AspNetCore.Authorization.dll"
    },
    {
      "hash": "sha256-h9QCIGsAXcc3LDbZw6Z8Hbd3VtGFCACj3TYr4XQLWaY=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-noHznLuDwoko2F\/letkw705vfZf14FS4ZucQJVDrVYY=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-INkINaU7UXGrZIrdtaGt6jRN7yE3ZMRfBL7Xb9mu0WQ=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-uNSjjzGZan\/E0U\/\/2zL3Bmh2b0xMTpC\/kotSPQa4MbI=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-ac4stn1eobk9p\/24HUlvMqxpBymazpNVPsU3i5FCNKM=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-BJeRgbVSljLQ+sCKsDWwFbyJvkSF84fed7rcf5+GK4s=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-GcqOItT9TLap0aRlf66Tqc0ycCSRvh9ZZ2eP2AnyT90=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-tVIcXoAy9SgH+UQFCQG6f\/hmqrj8Bnwqz9AJaaLNsjw=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-P4+OD1nLY6yvBQbLWf3XALEAjGjsmOqrdAhj1SmCL1U=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-VtXlw8ZzXr\/uJukIxl2amVlI0iX5AudhX8bQF2k1mjI=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-JVBNiak\/8B3AcQkWEGr3wUXTGCHLabZtaMFtFk71jtE=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-YN\/6L13xwKXlQKSE2J4adk29vhT4SWM\/6Cz1R4E+tvI=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-UQLLfErWJmykNU\/8fVl1tpNwAVaDmX6UFcBr2P2SgMk=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-114c7Kng5wf2dRo39ix9XLd9gu\/uEVko0oqnNohR3rA=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-YlYt1zT1hT+aqQZN29dDxRiK4W\/IlVEC3wpLUTx9jtY=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-QV6B1p\/dQJO7qHvPN0JZr5UKKFp+s9zZSnViNcpgVN8=",
      "url": "_framework\/Microsoft.Win32.SystemEvents.dll"
    },
    {
      "hash": "sha256-gsQ+EjDYkrhe7kTqy33UpGj+uuk4cxFHZtqpfp0IxP4=",
      "url": "_framework\/SixLabors.ImageSharp.dll"
    },
    {
      "hash": "sha256-\/nqyAnvdi73A9cdw6atogTlDcHOIBucZgtooaTF4yCg=",
      "url": "_framework\/SkiaSharp.dll"
    },
    {
      "hash": "sha256-dwtIoWQRFC7p1tlAJ7t97eQP9V3zyrjSdzHn0aaC4HM=",
      "url": "_framework\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-3ET+mpR7F058YRj9YaLHOVXBqOW6iUxtIpeiKPYw4PA=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-YfsH+27emzFjOO0TsznNWz35mEIKEk2tsdcONeNLIS4=",
      "url": "_framework\/zxing.dll"
    },
    {
      "hash": "sha256-gz7LYQxg0s7g8hElFRq9vJtV3SxKvZl1tHmd45NOJ1Y=",
      "url": "_framework\/ZXing.SkiaSharp.dll"
    },
    {
      "hash": "sha256-+J0wslUTXroIRs9G830UU7AKC26iUJzpsFDEWdzb0H4=",
      "url": "_framework\/BarcodeGenerator.dll"
    },
    {
      "hash": "sha256-8j\/d1uD8VduPLbeS+USAJ9Z\/kTKsZtrNguq4Henca9s=",
      "url": "_framework\/System.Buffers.dll"
    },
    {
      "hash": "sha256-wmJ6A85YJtMHpTo6upAXVpsFPvyJksFfCtRusIkS\/wE=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-3FkNprYoMTx+TQ8XLElVcwmpPF2JVcj8k\/W3DWK90+A=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-\/BOXMAeNQUC8AH0TgOL7UyWaDdkKSxEwqX9ItWoIGp0=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-ORtqNA\/aVvG2UO6hR3RAlzskWOgOwzpU54yThSDN3kQ=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-iyCXipNB4edWPI00kr49bh8ZVP\/gvfbH9xWrUjDlV04=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-vP0ePcCYa0BF2RvThhNjM\/QvtMjni5xYLNQwDsm54+0=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-ug3euMwoOhORe7lfJtRKum3kVPIq1o22Rwbz4XDziCQ=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-B4VoxOl0BmM2+Hl1nBpiLnDAUmuVELtuE5tHC9c7FS8=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-6Fm\/SzZXYQr6XCojoyvsRwkIqkYlRehdgObBC7JanF4=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-OZkfTGt2VdohMXnU\/t8\/3ArYk7efehAxvwVOzlERvdc=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-DFD5LxtgEA5f9gCXggtbu5cRxdct1IZRM1aJGQ5spk8=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-RvAHIoF0lgegXLUak9nzAERNC\/0tjzDa8ej4qIuMgPA=",
      "url": "_framework\/System.Diagnostics.Tools.dll"
    },
    {
      "hash": "sha256-JKU3wXn80R3jyI+e+UxQjJuusyhIsPRCB+XAusQLjLg=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-Ux+h\/q9hyz4SCm8D48cqQjlFll99vacooF0h+KlJ9rA=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-nAvPp9vktPcYmCv5\/O9JlRGEzaivoI5XV57NER+j+l4=",
      "url": "_framework\/System.Drawing.dll"
    },
    {
      "hash": "sha256-3jR7upl792y2EwJhNM6Zbl0eZdxnZk+dLGJpzqBiOmU=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-Cd4CunyMBCbbCc5yuK3mDTL8yEk6HzkqplveaQHBu5g=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-HyFfBIVWEh7Haoxis9KON2bgmlfVvOOVRBRBdkixHP8=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-NsVEl5HZjRRbo\/x5MUHF6CiYC8PjECfreZbhmywOEGo=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-\/bFzEUOTRsiIhqMk52DlZEn\/1Oq++fZxWmBu3+qy1p4=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-2VPga0LUxgDqQRFqQgWHsTsWR8gCYqBKNyfc7q8bqEA=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-5G+\/0Dpsa\/9kvy+5z+wiSDz63XSifaQH4LAq4D5DghY=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-hjzWhRVMeCXP\/wCEIOLnAOm1bY9ndSrdnCpiI6ZSq4w=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-58qVUpi\/\/0l4DOkcHUNsHt274JDa5UoOJRcpZMS8wVU=",
      "url": "_framework\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-shz80Qr5ZlyCNPSKCWCNeSUv\/s7QCFj0OcG6epdAr7U=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-zjNdFCM6qJpnwD38kKDStxvR83qtP5DAHZ1V5qv13eU=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-7SXTcKYSh4cWqRbkYNxegCLzeI4sm0YMzkyv5cI7Y\/M=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-Cs1\/Ix1OJe4oyWwB9dTP1tR0+rv50UIffEQYFjkReXs=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-fDEMd6MdlSSZr3xMRVsNxH07CRxCG1YvWS9cFaghEPw=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-4tlSLVfM\/Nk2pzVPHljeYBONt\/SuXWmzPBqM9KXgkrU=",
      "url": "_framework\/System.Runtime.Extensions.dll"
    },
    {
      "hash": "sha256-jnplcnKd2tnt9Anvrhnyn02eSIH9fSK8hcFaT8GV9As=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-\/NqVsYCXprCMnp4fQEIY+YarEFzORAxPBWRUpqmLSwI=",
      "url": "_framework\/System.Runtime.InteropServices.dll"
    },
    {
      "hash": "sha256-4xufV607EDu+qzYicr+\/mcHCGmvAJ+MV9pmYvi8QMyA=",
      "url": "_framework\/System.Runtime.Intrinsics.dll"
    },
    {
      "hash": "sha256-WFfO5PuS\/jy7f458ltHolH1Cufia9wYoom6tCS2mcWM=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-jimcTCWhcyZysytJGoI4b\/Kcy9PSt6Bdif4DKiBlBrI=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-3rx86V6Oqa1oa+AJ5eCRKfAx2KuCM3eHok1CeYNY0co=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-3+AkaQLcsZYygsTgmmPdXGPwVThdzbIoCBPYPAvVnRg=",
      "url": "_framework\/System.Security.Cryptography.Primitives.dll"
    },
    {
      "hash": "sha256-DSbtBgUS49MADVa3GwIXM0mi4ZZgURIyo\/LxiP6aZ8M=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-oRulDXaVlMYH\/0vDgWRIhivibD7uF7NJOQl4MeOcpLw=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-Y0LFGbiJorTgvLJk4KrKpMF3RrHjFeOQOHJEH8j7yx8=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-6XSaql0NOK2n1WMaJvbXdBOUvkai8UkW+I2DjAd7VpI=",
      "url": "_framework\/System.Threading.Tasks.Parallel.dll"
    },
    {
      "hash": "sha256-bPkCYQgTx5Zf+CZukrv2PKpdw3SyIpxjCPNCX9\/rCiE=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-PNGkToQipDqwTh\/6z52NwdJ8GUk7wcG0dF2gzinDkmI=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-yJGwdi0v0sW\/EmCNjECP8l\/3+rHA8jqjfjRTSmZy34Q=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-\/X1GLT\/fztZwHSGwkc\/vYBFk1tHphk2yO9lmCxhgGzU=",
      "url": "_framework\/System.dll"
    },
    {
      "hash": "sha256-w4d876tFodX+\/1I4fpn3haUsCySEdETt35iXg4eyODw=",
      "url": "_framework\/netstandard.dll"
    },
    {
      "hash": "sha256-7\/eqO8obPV72H1JlDZ+d9pUYAqmjZpUH7\/D8D\/G7ymY=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-NZibAhuPjzS17bYHfMqYZsYcsjKTTbvUL+5U3dDwpEI=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "+16lKhnN"
};
